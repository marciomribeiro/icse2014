package lancs.midp.mobilephoto.lib.exceptions;

public class InvalidImageFormatException extends InvalidImageDataException {

	public InvalidImageFormatException() {
	}

	public InvalidImageFormatException(String arg0) {
		super(arg0);
	}

	public InvalidImageFormatException(Throwable arg0) {
		super(arg0);
	}
}
