package lancs.midp.mobilephoto.lib.exceptions;

public class InvalidPhotoAlbumNameException extends Exception {

	public InvalidPhotoAlbumNameException() {
	}

	public InvalidPhotoAlbumNameException(String s) {
		super(s);
	}
}
