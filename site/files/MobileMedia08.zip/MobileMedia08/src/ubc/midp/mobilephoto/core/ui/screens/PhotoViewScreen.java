// #ifdef includePhotoAlbum
// [NC] Added in the scenario 07

package ubc.midp.mobilephoto.core.ui.screens;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import ubc.midp.mobilephoto.core.ui.datamodel.AlbumData;
import ubc.midp.mobilephoto.core.util.Constants;
import ubc.midp.mobilephoto.core.util.MediaUtil;

/**
 * This screen displays a selected image.
  */
public class PhotoViewScreen extends Canvas {

    Image image;
    AlbumData model = null;

    // #ifdef includeSmsFeature
    /* [NC] Added in scenario 06 */
    byte[] byteImage = null;
    // #endif

    public static final Command backCommand = new Command("Back", Command.BACK, 0);

    // #if includeCopyPhoto || includeSmsFeature
    /* [EF] Added in scenario 05 */
    public static final Command copyCommand = new Command("Copy", Command.ITEM, 1);
    // #endif

    // #ifdef (zoom)
    /* [EF] Added in scenario 05 */
    public static final Command zoomPlusCommand = new Command("Zoom (+)", Command.ITEM, 2);
    public static final Command zoomMinusCommand = new Command("Zoom (-)", Command.ITEM, 3);
    // #endif

    // #ifdef includeSmsFeature
    /* [NC] Added in scenario 06 */
    public static final Command smscopyCommand = new Command("Send Photo by SMS", Command.ITEM, 1);
    private boolean fromSMS = false;
    // #endif

    /**
     * Constructor
     * @param img
     */
    public PhotoViewScreen(Image img) {

        //#ifdef (zoom)
        //Vector formats (like EPS, PS, and PDF) should have zoom.
        //So, add the zoom buttons into the screen!
        if (getImageFormat(MediaUtil.getByteArray(img)).equals("EPS")) {
            this.addCommand(zoomPlusCommand);
            this.addCommand(zoomMinusCommand);
        }
        //#endif

        this.addCommand(backCommand);

        //#ifdef (includeCopyPhoto  | includeSmsFeature)
        this.addCommand(copyCommand);
        //#endif

        //#ifdef (includeSmsFeature)
        /* [NC] Added in scenario 06 */
        this.addCommand(smscopyCommand);
        //#endif

        //Instead of loading it from a list, pass the image in directly
        image = img;

        //scroll?
        //rotate?
        //testar um jpg
        //get random image from internet
        //pdf/eps (teriam zoom)
        //ou o nome da feature é vetorial?
        //atualmente só funciona com um servidor que retorna imagens png e eps...
        //considere um metodo que usa um outro servidor com os seguintes tipos: png, bmp, eps e ps.
//        if ((img.getHeight() < Constants.SCREEN_HEIGHT) ||
//            (img.getWidth() < Constants.SCREEN_WIDTH)) {
//
//        }
    }
	
	/*
	 *  (non-Javadoc)
	 * @see javax.microedition.lcdui.Canvas#paint(javax.microedition.lcdui.Graphics)
	 */
	protected void paint(Graphics g) {
	    g.setGrayScale (255);

	    //Draw the image - for now start drawing in top left corner of screen
	    g.fillRect (0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);
	    System.out.println("Screen size:"+Constants.SCREEN_WIDTH+":"+ Constants.SCREEN_HEIGHT);

	    if (image == null) 
	    	System.out.println("PhotoViewScreen::paint(): Image object was null.");
	    	
	    g.drawImage (image, 0, 0, Graphics.TOP | Graphics.LEFT);

            int i = Graphics.TOP | Graphics.LEFT;
            int i2 = Graphics.TOP | Graphics.RIGHT;
            int i3 = Graphics.BOTTOM | Graphics.LEFT;
            int i4 = Graphics.BOTTOM | Graphics.RIGHT;
            System.out.println("16 | 4 ==> " + i);
            System.out.println("16 | 8 ==> " + i2);
            System.out.println("32 | 4 ==> " + i3);
            System.out.println("32 | 8 ==> " + i4);
	}

	// #ifdef includeSmsFeature
	/* [NC] Added in scenario 06 */
	public void setImage(byte[] img){
		byteImage = img;
	}
	
	public byte[] getImage(){
		return byteImage;
	}
	
	public boolean isFromSMS() {
		return fromSMS;
	}
	
	public void setFromSMS(boolean fromSMS) {
		this.fromSMS = fromSMS;
	}
	// #endif

        private String getImageFormat(byte[] bytes) {

            int length = bytes.length;

            for (int i = 0; i < bytes.length; i++) {
                System.out.println("bytes[" + i + "] = " + bytes[i]);
            }

//            System.out.println("bytes[" + (length - 4) + "] = " + bytes[length - 4]);
//            System.out.println("bytes[" + (length - 3) + "] = " + bytes[length - 3]);
//            System.out.println("bytes[" + (length - 2) + "] = " + bytes[length - 2]);
//            System.out.println("bytes[" + (length - 1) + "] = " + bytes[length - 1]);

            if ((bytes[0] == 25) &&
                (bytes[1] == 21) &&
                (bytes[2] == 50) &&
                (bytes[3] == 53) &&
                (bytes[4] == 2D) &&
                (bytes[5] == 41) &&
                (bytes[6] == 64) &&
                (bytes[7] == 6F)) {
                return "EPS";

            } else if ((bytes[0] == 25) &&
                       (bytes[0] == 50) &&
                       (bytes[0] == 44) &&
                       (bytes[0] == 46)) {
                return "PDF";
            } else if ((bytes[length - 4] == Integer.parseInt("AE", 16)) &&
                       (bytes[length - 3] == 42) &&
                       (bytes[length - 2] == 60) &&
                       (bytes[length - 1] == 82)) {
                return "PNG";
            } else {
                return "PNG";
            }
        }
}
// #endif