package ubc.midp.mobilephoto.core.util;

import java.io.DataInputStream;
import java.io.IOException;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import javax.microedition.lcdui.Image;

/**
 *
 * @author Márcio Ribeiro
 */
public class NetworkFacade {

    public static Image loadImage(String server) {
        DataInputStream dis = null;
        try {
        	HttpConnection connection = (HttpConnection) Connector.open(server);
            int length = (int) connection.getLength();
            byte[] data = new byte[length];
            dis = new DataInputStream(connection.openInputStream());
            dis.readFully(data);

            return Image.createImage(data, 0, data.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}